tinyMCE.addI18n('sl.searchreplace_dlg',{
searchnext_desc:"Najdi znova",
notfound:"Preiskovanje zaklju\u010Deno. Iskanega besedila nisem na\u0161el.",
search_title:"Najdi",
replace_title:"Najdi/zamenjaj",
allreplaced:"Vse pojavitve iskanega besedila so bile zamenjane.",
findwhat:"I\u0161\u010Dem za",
replacewith:"Zamenjam z",
direction:"Smer",
up:"navzgor",
down:"navzdol",
mcase:"ujemanje velikosti",
findnext:"Najdi nasled.",
replace:"Zamenjaj",
replaceall:"Zamenjaj vse"
});