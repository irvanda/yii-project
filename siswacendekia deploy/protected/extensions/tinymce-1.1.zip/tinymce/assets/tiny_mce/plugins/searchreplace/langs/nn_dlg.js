tinyMCE.addI18n('nn.searchreplace_dlg',{
searchnext_desc:"S\u00F8k igjen",
notfound:"S\u00F8ket avslutta. Fann ikkje s\u00F8kjestrengen.",
search_title:"S\u00F8k",
replace_title:"S\u00F8k/Erstatt",
allreplaced:"Alle f\u00F8rekomstar av s\u00F8kjestrengen er erstatta.",
findwhat:"Finn kva",
replacewith:"Erstatt med",
direction:"Retning",
up:"Oppover",
down:"Nedover",
mcase:"Skill mellom store og sm\u00E5 teikn",
findnext:"Finn neste",
replace:"Erstatt",
replaceall:"Erstatt alt"
});