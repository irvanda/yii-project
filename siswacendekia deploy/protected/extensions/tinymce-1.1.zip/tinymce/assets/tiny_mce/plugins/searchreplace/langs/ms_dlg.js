tinyMCE.addI18n('ms.searchreplace_dlg',{
searchnext_desc:"Cari lagi",
notfound:"Carian tamat. Perkataan yang dicari tiada.",
search_title:"Cari",
replace_title:"Cari/Ganti",
allreplaced:"Kesemua perkataan telah digantikan.",
findwhat:"Cari apa",
replacewith:"Ganti dengan",
direction:"Arah",
up:"Atas",
down:"Bawah",
mcase:"Samakan kes",
findnext:"Carian seterusnya",
replace:"Ganti",
replaceall:"Ganti kesemuanya"
});