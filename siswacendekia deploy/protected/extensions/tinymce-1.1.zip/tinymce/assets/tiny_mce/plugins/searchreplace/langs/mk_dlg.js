tinyMCE.addI18n('mk.searchreplace_dlg',{
searchnext_desc:"Prona\u0111i opet",
notfound:"Pretra\u017Eivanje je zavr\u0161eno. Tra\u017Eeni tekst nije prona\u0111en.",
search_title:"Prona\u0111i",
replace_title:"Prona\u0111i/Zameni",
allreplaced:"Sva pojavljivanja tra\u017Eenog teksta su zamenjena.",
findwhat:"Prona\u0111i tekst",
replacewith:"Zameni sa",
direction:"Smjer",
up:"Gore",
down:"Dolje",
mcase:"Match case",
findnext:"Prona\u0111i sljede\u0107e",
replace:"Zameni",
replaceall:"Zameni sve"
});