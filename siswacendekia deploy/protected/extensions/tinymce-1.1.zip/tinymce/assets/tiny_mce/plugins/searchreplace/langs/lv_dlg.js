tinyMCE.addI18n('lv.searchreplace_dlg',{
searchnext_desc:"Mekl\u0113t v\u0113lreiz",
notfound:"Mekl\u0113\u0161ana pabeigta. Mekl\u0113t\u0101 fr\u0101ze/v\u0101rds netika atrasta.",
search_title:"Mekl\u0113t",
replace_title:"Mekl\u0113t/Aizvietot",
allreplaced:"Visas fr\u0101zes/v\u0101rdi tika veiksm\u012Bgi aizvietoti.",
findwhat:"Ko atrast",
replacewith:"Aizvietot ar",
direction:"Virziens",
up:"Uz aug\u0161u",
down:"Uz leju",
mcase:"Re\u0123istrj\u016Bt\u012Bgs",
findnext:"Mekl\u0113t n\u0101kamo",
replace:"Aizvietot",
replaceall:"Aizvietot visu"
});