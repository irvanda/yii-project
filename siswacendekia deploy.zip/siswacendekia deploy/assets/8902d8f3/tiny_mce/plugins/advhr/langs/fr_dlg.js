tinyMCE.addI18n('fr.advhr_dlg',{
width:"Largeur",
size:"Hauteur",
noshade:"Pas d'ombre"
});